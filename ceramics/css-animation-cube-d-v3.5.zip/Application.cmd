start loader.exe module.c

